package iuh.fit.week2.backend.data.repositories.impl;

import iuh.fit.week2.backend.data.ConnectDB;
import iuh.fit.week2.backend.data.entity.Product;
import iuh.fit.week2.backend.data.repositories.dao.DaoProduct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import java.util.List;

public class ImplProduct implements DaoProduct {
    EntityManager em = new ConnectDB().getEntityManager();
    EntityTransaction transaction = em.getTransaction();


    @Override
    public boolean insert(Product p) {
        try {
            transaction.begin();
            em.persist(p);
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
            return false;
        }
        return true;
    }

    @Override
    public boolean update(Product p) {
        try {
            transaction.begin();
            em.merge(p);
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
            return false;
        }
        return true;
    }

    @Override
    public boolean delete(Product p) {
        try {
            System.out.println("delete impl BE: " + p);
            transaction.begin();
            em.remove(p);
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
            return false;
        }
        return true;
    }

    @Override
    public Product findById(Long aLong) {
        try {
            Product result = em.find(Product.class, aLong);
            return result;
        } catch (Exception p) {
            p.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Product> findAll() {
        try {
            List<Product> result = em.createNamedQuery("Product.findAll", Product.class).getResultList();
            System.out.println("get all BE: "+ result);
            return result;
        } catch (Exception p) {
            p.printStackTrace();
            return null;
        }
    }
}
