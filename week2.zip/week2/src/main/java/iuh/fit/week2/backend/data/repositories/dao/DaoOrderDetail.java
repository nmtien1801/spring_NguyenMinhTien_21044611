package iuh.fit.week2.backend.data.repositories.dao;

import iuh.fit.week2.backend.data.entity.OrderDetail;

public interface DaoOrderDetail {
    public boolean insert(OrderDetail od);
}
