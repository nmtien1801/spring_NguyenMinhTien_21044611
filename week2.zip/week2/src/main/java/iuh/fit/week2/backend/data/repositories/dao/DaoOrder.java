package iuh.fit.week2.backend.data.repositories.dao;

import iuh.fit.week2.backend.data.entity.Order;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public interface DaoOrder {
    public boolean insert(Order p);

    public boolean update(Order p);

    public boolean delete(Order p);

    public Order findById(Long aLong);

    public List<Order> findAll();

    public List<Order> findOrdersByTimeRange(LocalDateTime startDate, LocalDateTime endDate) ;

    public List<Order> findOrdersByDay(LocalDate date);

    public List<Order> findOrdersByEmployeeAndTimeRange(Long empId, LocalDateTime startDate, LocalDateTime endDate);

    public Order findLatestOrder();
}
