package iuh.fit.week2.backend.data.entity.enums;

public enum StatusEmployee {
    TERMINATED, ACTIVE, IN_ACTIVE
}
