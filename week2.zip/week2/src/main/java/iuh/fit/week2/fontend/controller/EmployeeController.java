package iuh.fit.week2.fontend.controller;

import iuh.fit.week2.backend.data.entity.Employee;
import iuh.fit.week2.backend.data.entity.enums.StatusEmployee;
import iuh.fit.week2.fontend.model.EmployeeModel;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@WebServlet(name = "employeeController", value = "/employee")
public class EmployeeController extends HttpServlet {
    EmployeeModel model = new EmployeeModel();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");

        System.out.println("Action: " + action);

        if(action.equalsIgnoreCase("getall")){
            List<Employee> employees = model.getListEmployee();
            req.setAttribute("employees", employees);
            req.getRequestDispatcher("views/employee.jsp").forward(req, resp);

        }
        else{
            System.out.println("Action not found");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");

        System.out.println("Action: " + action);

        if(action.equalsIgnoreCase("insert")){
            String name = req.getParameter("name");
            String email = req.getParameter("email");
            String phone = req.getParameter("phone");
            String address = req.getParameter("address");
            StatusEmployee statusEmployee = StatusEmployee.valueOf(req.getParameter("status"));
            LocalDateTime localDateTime = LocalDateTime.parse(req.getParameter("dob"));
            Timestamp dob = Timestamp.valueOf(localDateTime);

            Employee e = new Employee();
            e.setFullName(name);
            e.setEmail(email);
            e.setPhone(phone);
            e.setAddress(address);
            e.setStatus(statusEmployee);
            e.setDob(dob);

            model.insertEmployee(e);
            resp.sendRedirect("employee?action=getall");
        }
        else if(action.equalsIgnoreCase("update")){
            String id = req.getParameter("id");
            String name = req.getParameter("name");
            String email = req.getParameter("email");
            String phone = req.getParameter("phone");
            String address = req.getParameter("address");
            StatusEmployee statusEmployee = StatusEmployee.valueOf(req.getParameter("status"));
            LocalDateTime localDateTime = LocalDateTime.parse(req.getParameter("dob"));
            Timestamp dob = Timestamp.valueOf(localDateTime);


            Employee e = model.getEmployee(id);
            e.setFullName(name);
            e.setEmail(email);
            e.setPhone(phone);
            e.setAddress(address);
            e.setStatus(statusEmployee);
            e.setDob(dob);

            System.out.println("update FE: " + e);

            model.putEmployee(e);
            resp.sendRedirect("employee?action=getall");
        }
        else if(action.equalsIgnoreCase("delete")){
            String id = req.getParameter("id");
            Employee e = model.getEmployee(id);


            model.deleteEmployee(id);
            resp.sendRedirect("employee?action=getall");
        }
        else{
            System.out.println("Action not found");
        }

    }
}
