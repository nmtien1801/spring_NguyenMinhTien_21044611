package iuh.fit.week2.backend.url;

import jakarta.ws.rs.ApplicationPath;

@ApplicationPath("/api")
public class Application extends jakarta.ws.rs.core.Application {
}
