package iuh.fit.week2.backend.data.repositories.impl;

import iuh.fit.week2.backend.data.ConnectDB;
import iuh.fit.week2.backend.data.entity.OrderDetail;
import iuh.fit.week2.backend.data.repositories.dao.DaoOrderDetail;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

public class ImplOrderDetail implements DaoOrderDetail {
    EntityManager em = new ConnectDB().getEntityManager();
    EntityTransaction transaction = em.getTransaction();

    @Override
    public boolean insert(OrderDetail od) {
        try {
            transaction.begin();
            em.merge(od);
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
            return false;
        }
        return true;
    }
}
