package iuh.fit.week2.backend.url.orderDetail;

import iuh.fit.week2.backend.data.entity.OrderDetail;
import iuh.fit.week2.backend.data.repositories.dao.DaoOrderDetail;
import iuh.fit.week2.backend.data.repositories.impl.ImplOrderDetail;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.core.Response;

@Path("/orderDetail")
public class UrlOrderDetail {
    DaoOrderDetail daoOrderDetail = new ImplOrderDetail();

    @POST
    @Consumes("application/json")
    @Path("/insert")
    public Response postOrderDetail(OrderDetail orderDetail) {
        if (daoOrderDetail.insert(orderDetail)) {
            System.out.println("insert success BE: " + orderDetail);
            return Response.ok().build();
        }
        return Response.status(500).build();
    }
}
