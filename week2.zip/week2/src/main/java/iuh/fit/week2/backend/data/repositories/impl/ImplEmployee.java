package iuh.fit.week2.backend.data.repositories.impl;

import iuh.fit.week2.backend.data.ConnectDB;
import iuh.fit.week2.backend.data.entity.Employee;
import iuh.fit.week2.backend.data.repositories.dao.DaoEmployee;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import java.util.List;

public class ImplEmployee implements DaoEmployee {
    EntityManager em = new ConnectDB().getEntityManager();
    EntityTransaction transaction = em.getTransaction();


    @Override
    public boolean insert(Employee p) {
        try {
            transaction.begin();
            em.persist(p);
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
            return false;
        }
        return true;
    }

    @Override
    public boolean update(Employee p) {
        try {
            transaction.begin();
            em.merge(p);
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
            return false;
        }
        return true;
    }

    @Override
    public boolean delete(Employee p) {
        try {
            System.out.println("delete impl BE: " + p);
            transaction.begin();
            em.remove(p);
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
            return false;
        }
        return true;
    }

    @Override
    public Employee findById(Long aLong) {
        try {
            Employee result = em.find(Employee.class, aLong);
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Employee> findAll() {
        try {
            List<Employee> result = em.createNamedQuery("Employee.findAll", Employee.class).getResultList();
            System.out.println("get all BE: "+ result);
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
