package iuh.fit.week2.backend.data;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Persistence;

public class ConnectDB {
    EntityManager em = null;

    public ConnectDB() {
        if (em == null) {
            em = Persistence
                    .createEntityManagerFactory("week2")
                    .createEntityManager();
        }
    }

    public EntityManager getEntityManager() {
        return em;
    }

    public void close() {
        if (em != null) {
            em.close();
        }
    }
}
