package iuh.fit.week2.backend.url.order;

import iuh.fit.week2.backend.data.entity.Order;
import iuh.fit.week2.backend.data.repositories.dao.DaoOrder;
import iuh.fit.week2.backend.data.repositories.impl.ImplOrder;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Response;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Path("/order")
public class UrlOrder {
    DaoOrder daoOrder = new ImplOrder();

    @GET
    @Produces("application/json")
    public Response getOrder() {
        return Response.ok(daoOrder.findAll()).build();
    }

    @GET
    @Produces("application/json")
    @Path("/{id}")
    public Response getOrder(@PathParam("id") Long id) {
        return Response.ok(daoOrder.findById(id)).build();
    }

    @POST
    @Consumes("application/json")
    @Path("/insert")
    public Response postOrder(Order order) {
        if (daoOrder.insert(order)) {
            System.out.println("insert success BE: " + order);
            return Response.ok().build();
        }
        return Response.status(500).build();
    }

    @PUT
    @Consumes("application/json")
    @Path("/update")
    public Response putOrder(Order order) {
        if (daoOrder.update(order)) {
            System.out.println("update success BE: " + order);
            return Response.ok().build();
        }
        return Response.status(500).build();
    }

    @DELETE
    @Consumes("application/json")
    @Path("/delete/{id}")
    public Response deleteOrder(@PathParam("id") Long id) {
        Order order = daoOrder.findById(id);
        System.out.println("delete success BE: " + order);

        if (daoOrder.delete(order)) {

            return Response.ok().build();
        }
        return Response.status(500).build();
    }

    @GET
    @Produces("application/json")
    @Path("/findByDay")
    public Response findOrdersByDay(@QueryParam("date") String date) {
        LocalDate localDate = LocalDate.parse(date);
        List<Order> orders = daoOrder.findOrdersByDay(localDate);
        return Response.ok(orders).build();
    }

    @GET
    @Produces("application/json")
    @Path("/findByTimeRange")
    public Response findOrdersByTimeRange(@QueryParam("startDate") String startDate, @QueryParam("endDate") String endDate) {
        LocalDateTime startDateTime = LocalDateTime.parse(startDate);
        LocalDateTime endDateTime = LocalDateTime.parse(endDate);
        List<Order> orders = daoOrder.findOrdersByTimeRange(startDateTime, endDateTime);
        return Response.ok(orders).build();
    }

    // vieets response findByEmployeeAndTimeRange
    @GET
    @Produces("application/json")
    @Path("/findByEmployeeAndTimeRange")
    public Response findOrdersByEmployeeAndTimeRange(@QueryParam("empId") Long empId, @QueryParam("startDate") String startDate, @QueryParam("endDate") String endDate) {
        LocalDateTime startDateTime = LocalDateTime.parse(startDate);
        LocalDateTime endDateTime = LocalDateTime.parse(endDate);
        List<Order> orders = daoOrder.findOrdersByEmployeeAndTimeRange(empId, startDateTime, endDateTime);
        return Response.ok(orders).build();
    }

    @GET
    @Produces("application/json")
    @Path("/latest")
    public Response findLatestOrder() {
        Order order = daoOrder.findLatestOrder();
        return Response.ok(order).build();
    }
}
