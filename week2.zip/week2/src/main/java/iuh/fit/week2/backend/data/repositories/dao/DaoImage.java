package iuh.fit.week2.backend.data.repositories.dao;

import iuh.fit.week2.backend.data.entity.ProductImage;

import java.util.List;

public interface DaoImage {
    public List<ProductImage> findAll();
}
