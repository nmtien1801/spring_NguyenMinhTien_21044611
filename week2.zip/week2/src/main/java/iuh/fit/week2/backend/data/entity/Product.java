package iuh.fit.week2.backend.data.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import iuh.fit.week2.backend.data.entity.enums.StatusProduct;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

import java.util.LinkedHashSet;
import java.util.Set;

@Entity
@Table(name = "product")
@NamedQueries({
        @NamedQuery(name = "Product.findAll", query = "select p from Product p"),
        @NamedQuery(name = "Product.findById", query = "select p from Product p where p.id = :id")
})
@ToString @Getter @Setter
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "product_id", nullable = false)
    private Long id;

    @Size(max = 255)
    @Column(name = "description")
    private String description;

    @Size(max = 255)
    @Column(name = "manufacturer")
    private String manufacturer;

    @Size(max = 255)
    @NotNull
    @Column(name = "name", nullable = false)
    private String name;

    @NotNull
    @Lob
    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false)
    private StatusProduct status;

    @Size(max = 255)
    @NotNull
    @Column(name = "unit", nullable = false)
    private String unit;

    @OneToMany(mappedBy = "product")
    @ToString.Exclude
    @JsonIgnore
    private Set<ProductImage> images;

    @ManyToMany(mappedBy = "products")
    @ToString.Exclude
    @JsonIgnore
    private Set<Order> orders;

    @OneToMany(mappedBy = "product")
    @ToString.Exclude
    @JsonIgnore
    private Set<ProductPrice> prices;

}