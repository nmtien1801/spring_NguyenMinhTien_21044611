package iuh.fit.week2.backend.data.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;
import java.time.Instant;

@Entity
@Table(name = "product_price")
@NamedQueries({
        @NamedQuery(name = "ProductPrice.findAll", query = "select p from ProductPrice p"),
        @NamedQuery(name = "ProductPrice.findByPrice", query = "select p from ProductPrice p where p.price = :price")
})
@ToString @Getter @Setter
public class ProductPrice {
    @Id
    @Column(name = "price_date_time", nullable = false)
    private Timestamp priceDateTime;

    private String note;
    private double price;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "product_id", nullable = false)
    @ToString.Exclude
    private Product product;

}
