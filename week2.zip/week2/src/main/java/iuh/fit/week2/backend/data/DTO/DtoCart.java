package iuh.fit.week2.backend.data.DTO;

import lombok.*;

@ToString @Getter @Setter @AllArgsConstructor @NoArgsConstructor
public class DtoCart {
    private Long id;
    private String path = "https://images.unsplash.com/photo-1529374255404-311a2a4f1fd9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60";
    private String name;
    private double price;
    private int quantity;
}
