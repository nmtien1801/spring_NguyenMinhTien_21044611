package iuh.fit.week2.backend.data.repositories.impl;

import iuh.fit.week2.backend.data.ConnectDB;
import iuh.fit.week2.backend.data.DTO.DtoProduct;
import iuh.fit.week2.backend.data.entity.Product;
import iuh.fit.week2.backend.data.entity.ProductImage;
import iuh.fit.week2.backend.data.entity.ProductPrice;
import iuh.fit.week2.backend.data.repositories.dao.DaoImage;
import iuh.fit.week2.backend.data.repositories.dao.DaoPrice;
import iuh.fit.week2.backend.data.repositories.dao.DaoProduct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import java.util.ArrayList;
import java.util.List;

public class ImpDtoproduct {
    EntityManager em = new ConnectDB().getEntityManager();
    EntityTransaction transaction = em.getTransaction();

    DaoProduct daoProduct = new ImplProduct();
    DaoImage daoImage = new ImpImage();
    DaoPrice daoPrice = new ImplPrice();

    public List<DtoProduct> getAllDtoProduct(){
        List<DtoProduct> d = new ArrayList<>();
        try {
            transaction.begin();
            List<Product> products = daoProduct.findAll();
            List<ProductImage> productImages = daoImage.findAll();
            List<ProductPrice> productPrices = daoPrice.findAll();

            String pathImage = productImages.get(0).getPath();
            double price = productPrices.get(0).getPrice();

            for (Product p : products) {
                DtoProduct dtoProduct = new DtoProduct();
                dtoProduct.setId(p.getId());
                dtoProduct.setDescription(p.getDescription());
                dtoProduct.setManufacturer(p.getManufacturer());
                dtoProduct.setName(p.getName());
                dtoProduct.setStatus(p.getStatus().toString());
                dtoProduct.setUnit(p.getUnit());
                dtoProduct.setPrice(price);
                dtoProduct.setPath(pathImage);
                d.add(dtoProduct);
            }
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
            return null;
        }
        return d;
    }
}
