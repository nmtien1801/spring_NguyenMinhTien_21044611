package iuh.fit.week2.backend.data.repositories.impl;

import iuh.fit.week2.backend.data.ConnectDB;
import iuh.fit.week2.backend.data.entity.Customer;
import iuh.fit.week2.backend.data.entity.Order;
import iuh.fit.week2.backend.data.repositories.dao.DaoCustomer;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import java.util.List;

public class ImplCustomer implements DaoCustomer {
    EntityManager em = new ConnectDB().getEntityManager();
    EntityTransaction transaction = em.getTransaction();

    @Override
    public boolean insert(Customer p) {
        try {
            transaction.begin();
            em.persist(p);
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
            return false;
        }
        return true;
    }

    @Override
    public boolean update(Customer p) {
        try {
            transaction.begin();
            em.merge(p);
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
            return false;
        }
        return true;
    }

    @Override
    public boolean delete(Customer p) {
        try {
            System.out.println("delete impl BE: " + p);
            transaction.begin();
            em.remove(p);
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
            return false;
        }
        return true;
    }

    @Override
    public Customer findById(Long aLong) {
        try {
            return em.find(Customer.class, aLong);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Customer> findAll() {
        try {
            List<Customer> result = em.createNamedQuery("Customer.findAll", Customer.class).getResultList();
            System.out.println("get all BE: "+ result);
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("get all BE err: "+ e);
            return null;
        }
    }
}


