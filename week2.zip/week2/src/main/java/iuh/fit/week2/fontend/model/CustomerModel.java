package iuh.fit.week2.fontend.model;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import iuh.fit.week2.backend.data.entity.Customer;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;

import java.util.ArrayList;
import java.util.List;

public class CustomerModel {
    private static final String URL = "http://localhost:8080/api/customer/";

    public List<Customer> getListCustomer() {
        List<Customer> customers = new ArrayList<>();
        try (Client client = ClientBuilder.newClient()) {
            WebTarget target = client.target(URL);

            String json = target
                    .request(MediaType.APPLICATION_JSON)
                    .get()
                    .readEntity(String.class);

            ObjectMapper mapper = new ObjectMapper();
            customers = mapper.readValue(json, new TypeReference<List<Customer>>() {
            });

            System.out.println("customers FE: " + customers);

        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }

        return customers;
    }

    public Customer getCustomer(String id) throws JsonProcessingException {
        if (id == null) {
            throw new IllegalArgumentException("Customer ID cannot be null");
        }
        Customer e = new Customer();
        try (Client client = ClientBuilder.newClient()) {
            WebTarget target = client.target(URL)
                    .path(id);

            String json = target
                    .request(MediaType.APPLICATION_JSON)
                    .get()
                    .readEntity(String.class);

            ObjectMapper mapper = new ObjectMapper();
            e = mapper.readValue(json, Customer.class);

            System.out.println("get customer FE: " + e);

        } catch (JsonProcessingException e1) {
            throw new RuntimeException(e1);
        }

        return e;
    }

    public boolean insertCustomer(Customer customer) {
        try (Client client = ClientBuilder.newClient()) {
            WebTarget target = client.target(URL)
                    .path("insert");

            String json = new ObjectMapper().writeValueAsString(customer);

            return target
                    .request(MediaType.APPLICATION_JSON)
                    .post(jakarta.ws.rs.client.Entity.entity(json, MediaType.APPLICATION_JSON))
                    .getStatus() == 200;
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    public boolean putCustomer(Customer customer) {
        try (Client client = ClientBuilder.newClient()) {
            WebTarget target = client.target(URL)
                    .path("update");

            String json = new ObjectMapper().writeValueAsString(customer);

            return target
                    .request(MediaType.APPLICATION_JSON)
                    .put(Entity.entity(json, MediaType.APPLICATION_JSON))
                    .getStatus() == 200;
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    public boolean deleteCustomer(String id) {
        try (Client client = ClientBuilder.newClient()) {
            WebTarget target = client.target(URL)
                    .path("delete/").path(id);



//            String json = new ObjectMapper().writeValueAsString(customer);
//            System.out.println("delete model FE: " + json);
            return target
                    .request(MediaType.APPLICATION_JSON)
                    .delete()
                    .getStatus() == 200;
        }
    }
}
