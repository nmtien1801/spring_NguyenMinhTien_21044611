package iuh.fit.week2.backend.data.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.Set;

@Entity
@Table(name = "orders")
@NamedQueries({
        @NamedQuery(name = "Order.findAll", query = "select o from Order o"),
        @NamedQuery(name = "Order.findByEmp_Id", query = "select o from Order o where o.emp.id = :id")
})
@ToString @Getter @Setter
public class Order {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "orders_SEQ")
    @SequenceGenerator(name = "orders_SEQ", sequenceName = "orders_SEQ", allocationSize = 1)
    @Column(name = "order_id", nullable = false)
    private Long id;

    @NotNull
    @Column(name = "order_date", nullable = false)
    private Timestamp orderDate;

    @NotNull
    @ManyToOne
    @JoinColumn(name = "emp_id", nullable = false)
    @ToString.Exclude
    private Employee emp;

    @NotNull
    @ManyToOne
    @JoinColumn(name = "cust_id", nullable = false)
    @ToString.Exclude
    private Customer cust;

    @ManyToMany
    @JoinTable(
            name = "order_detail",
            joinColumns = @JoinColumn(name = "order_id"),
            inverseJoinColumns = @JoinColumn(name = "product_id")
    )
    @ToString.Exclude
    @JsonIgnore
    private Set<Product> products;


}
