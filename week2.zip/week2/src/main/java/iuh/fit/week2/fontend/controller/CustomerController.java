package iuh.fit.week2.fontend.controller;

import iuh.fit.week2.backend.data.entity.Customer;
import iuh.fit.week2.fontend.model.CustomerModel;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@WebServlet(name = "customerController", value = "/customer")
public class CustomerController extends HttpServlet {
    CustomerModel model = new CustomerModel();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");

        System.out.println("Action: " + action);

        if(action.equalsIgnoreCase("getall")){
            List<Customer> customers = model.getListCustomer();
            req.setAttribute("customers", customers);
            req.getRequestDispatcher("views/customer.jsp").forward(req, resp);

        }
        else{
            System.out.println("Action not found");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");

        System.out.println("Action: " + action);

        if(action.equalsIgnoreCase("insert")){
            String name = req.getParameter("name");
            String email = req.getParameter("email");
            String phone = req.getParameter("phone");
            String address = req.getParameter("address");

            Customer c = new Customer();
            c.setCustName(name);
            c.setAddress(address);
            c.setEmail(email);
            c.setPhone(phone);

            model.insertCustomer(c);
            resp.sendRedirect("customer?action=getall");
        }
        else if(action.equalsIgnoreCase("update")){
            String id = req.getParameter("id");
            String name = req.getParameter("name");
            String email = req.getParameter("email");
            String phone = req.getParameter("phone");
            String address = req.getParameter("address");


            Customer c = model.getCustomer(id);
            c.setCustName(name);
            c.setAddress(address);
            c.setEmail(email);
            c.setPhone(phone);

            System.out.println("update FE: " + c);

            model.putCustomer(c);
            resp.sendRedirect("customer?action=getall");
        }
        else if(action.equalsIgnoreCase("delete")){
            String id = req.getParameter("id");
            Customer c = model.getCustomer(id);


            model.deleteCustomer(id);
            resp.sendRedirect("customer?action=getall");
        }
        else{
            System.out.println("Action not found");
        }

    }
}
