package iuh.fit.week2.backend.data.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.*;

@Entity
@Table(name = "order_detail")
@NamedQueries({
        @NamedQuery(name = "OrderDetail.findById_OrderId", query = "select o from OrderDetail o where o.id.orderId = :orderId"),
        @NamedQuery(name = "OrderDetail.findById_ProductId", query = "select o from OrderDetail o where o.id.productId = :productId")
})
@ToString @Getter @Setter @NoArgsConstructor @AllArgsConstructor
public class OrderDetail {
    @EmbeddedId
    private OrderDetailId id;

    @MapsId("orderId")
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "order_id")
    @ToString.Exclude  // Không cập nhật trực tiếp column này
    private Order order;

    @MapsId("productId")
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "product_id")
    @ToString.Exclude  // Không cập nhật trực tiếp column này
    private Product product;

    @Column(name = "quantity")
    private int quantity;

    @NotNull
    @Column(name = "price", nullable = false)
    private Double price;

    @Size(max = 255)
    @NotNull
    @Column(name = "note", nullable = false)
    private String note;

}
