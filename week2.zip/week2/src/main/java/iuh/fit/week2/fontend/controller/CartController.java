package iuh.fit.week2.fontend.controller;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import iuh.fit.week2.backend.data.DTO.DtoCart;
import iuh.fit.week2.backend.data.entity.*;
import iuh.fit.week2.fontend.model.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.transaction.Transactional;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;

@WebServlet(name = "CartController", value = "/cart")
public class CartController extends HttpServlet {
    private CartModel cartModel = new CartModel();
    private ProductModel productModel = new ProductModel();
    EmployeeModel employeeModel = new EmployeeModel();
    CustomerModel customerModel = new CustomerModel();
    OrderModel orderModel = new OrderModel();
    OrderDetailModel orderDetailModel = new OrderDetailModel();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");

        if (action != null && action.equalsIgnoreCase("getall")) {
            List<DtoCart> cartItems = cartModel.getCartItems();
            List<Employee> employees = employeeModel.getListEmployee();
            List<Customer> customers = customerModel.getListCustomer();

            req.setAttribute("cartItems", cartItems);
            req.setAttribute("employees", employees);
            req.setAttribute("customers", customers);
            req.getRequestDispatcher("views/cart.jsp").forward(req, resp);
        } else if (action.equalsIgnoreCase("pay")) {
            String jsonData = req.getParameter("data");
            if (jsonData != null) {
                JsonObject data = JsonParser.parseString(jsonData).getAsJsonObject();
                String empId = data.get("empId").getAsString();
                String cusId = data.get("cusId").getAsString();
                JsonArray cartItems = data.get("cartItems").getAsJsonArray();

//                 tao hoa don
                Employee employee = employeeModel.getEmployee(empId);
                Customer customer = customerModel.getCustomer(cusId);
                LocalDateTime localDateTime = LocalDateTime.now();
                Timestamp orderDate = Timestamp.valueOf(localDateTime);

                Order o = new Order();
                o.setEmp(employee);
                o.setCust(customer);
                o.setOrderDate(orderDate);

//                 them hoa don vao csdl
                if (orderModel.insertOrder(o)) {
                    //                 them chi tiet hoa don vao csdl
                    Order o_latest = orderModel.findLatestOrder();
                    System.out.println(">>>>> Order latest: " + o_latest);

                    for (int i = 0; i < cartItems.size(); i++) {
                        JsonObject cartItem = cartItems.get(i).getAsJsonObject();

                        String productId = cartItem.get("productId").getAsString();
                        int quantity = cartItem.get("quantity").getAsInt();
                        double price = cartItem.get("price").getAsDouble();


                        Product p = productModel.getProduct(productId);

                        // Tạo và lưu chi tiết hóa đơn
                        OrderDetailId orderDetailId = new OrderDetailId(o_latest.getId(), p.getId());

                        OrderDetail orderDetail = new OrderDetail();
                        orderDetail.setId(orderDetailId); // Gán ID nhúng
                        orderDetail.setOrder(o_latest);
                        orderDetail.setPrice(price);
                        orderDetail.setQuantity(quantity);
                        orderDetail.setProduct(p);
                        orderDetail.setNote("");
                        orderDetailModel.insertOrderDetail(orderDetail);
                    }
                }

                // xoa gio hang
                cartModel.clearCart();

                // chuyen huong ve trang chu
//                req.getRequestDispatcher("product?action=home").forward(req, resp);
                resp.sendRedirect("product?action=home");
            }


        } else {
            // Handle other actions
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");
        if (action != null && action.equalsIgnoreCase("add")) {
            Long productId = Long.parseLong(req.getParameter("productId"));
            String name = req.getParameter("name");
            double price = Double.parseDouble(req.getParameter("price"));
            int quantity = Integer.parseInt(req.getParameter("quantity"));
            String path = "https://images.unsplash.com/photo-1529374255404-311a2a4f1fd9?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60";
            List<DtoCart> dtoCarts = cartModel.getCartItems();

            boolean productExists = false;

            // Kiểm tra xem sản phẩm đã tồn tại trong giỏ hay chưa
            for (DtoCart cartItem : dtoCarts) {
                if (cartItem.getId().equals(productId)) {
                    cartItem.setQuantity(cartItem.getQuantity() + quantity); // Tăng số lượng
                    productExists = true;
                    break;
                }
            }

            // Nếu sản phẩm chưa có trong giỏ, thêm mới
            if (!productExists) {
                DtoCart product = new DtoCart(productId, path, name, price, quantity);
                cartModel.addProductToCart(product);
            }

            // Chuyển hướng về trang sản phẩm
            resp.sendRedirect("product?action=home");
        }

    }
}