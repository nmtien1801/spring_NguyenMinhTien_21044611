package iuh.fit.week2.backend.url.customer;

import iuh.fit.week2.backend.data.entity.Customer;
import iuh.fit.week2.backend.data.repositories.dao.DaoCustomer;
import iuh.fit.week2.backend.data.repositories.impl.ImplCustomer;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Response;

@Path("/customer")
public class UrlCustomer {
    DaoCustomer daoCustomer = new ImplCustomer();

    @GET
    @Produces("application/json")
    public Response getCustomer() {
        return Response.ok(daoCustomer.findAll()).build();
    }

    @GET
    @Produces("application/json")
    @Path("/{id}")
    public Response getCustomer(@PathParam("id") Long id) {
        return Response.ok(daoCustomer.findById(id)).build();
    }

    @POST
    @Consumes("application/json")
    @Path("/insert")
    public Response postCustomer(Customer customer) {
        if (daoCustomer.insert(customer)) {
            System.out.println("insert success BE: " + customer);
            return Response.ok().build();
        }
        return Response.status(500).build();
    }

    @PUT
    @Consumes("application/json")
    @Path("/update")
    public Response putCustomer(Customer customer) {
        if (daoCustomer.update(customer)) {
            System.out.println("update success BE: " + customer);
            return Response.ok().build();
        }
        return Response.status(500).build();
    }

    @DELETE
    @Consumes("application/json")
    @Path("/delete/{id}")
    public Response deleteCustomer(@PathParam("id") Long id) {
        Customer customer = daoCustomer.findById(id);
        System.out.println("delete success BE: " + customer);

        if (daoCustomer.delete(customer)) {

            return Response.ok().build();
        }
        return Response.status(500).build();
    }    
}
