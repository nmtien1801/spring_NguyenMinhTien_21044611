package iuh.fit.week2.backend.data.repositories.dao;

import iuh.fit.week2.backend.data.entity.Employee;

import java.util.List;

public interface DaoEmployee {
    public boolean insert(Employee p);

    public boolean update(Employee p);

    public boolean delete(Employee p);

    public Employee findById(Long aLong);

    public List<Employee> findAll();
}
