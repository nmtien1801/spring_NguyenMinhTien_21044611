package iuh.fit.week2.backend.data;

import iuh.fit.week2.backend.data.entity.Product;
import iuh.fit.week2.backend.data.entity.ProductImage;
import iuh.fit.week2.backend.data.entity.ProductPrice;
import iuh.fit.week2.backend.data.entity.enums.StatusProduct;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

import java.sql.Timestamp;
import java.time.LocalDateTime;

public class CreateDB {
    public static void main(String[] args) {
          EntityManager em = Persistence
                .createEntityManagerFactory("week2")
                .createEntityManager();

        EntityTransaction transaction = em.getTransaction();

        try {
            transaction.begin();

            // 1. Tạo Product
            Product product = new Product();
            product.setName("Product A");
            product.setDescription("High quality product");
            product.setManufacturer("Manufacturer A");
            product.setUnit("Piece");
            product.setStatus(StatusProduct.ACTIVE);
            em.persist(product);
            em.flush();

            // 2. Tạo ProductImage
            ProductImage image1 = new ProductImage();
            image1.setPath("https://example.com/image1.jpg");
            image1.setAlternative("Image 1");
            image1.setProduct(product); // Liên kết với Product
            em.persist(image1);
            em.flush();

            // 3. Tạo ProductPrice
            ProductPrice price = new ProductPrice();
            price.setPrice(143.00);
            price.setProduct(product); // Liên kết với Product
            price.setNote("Price for 1 piece");
            price.setPriceDateTime(Timestamp.valueOf(LocalDateTime.now()));
            em.persist(price);

            transaction.commit();

            System.out.println("Inserted Product, ProductImage, and ProductPrice successfully!");

        } catch (Exception e) {
            if (transaction.isActive()) {
                transaction.rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
        }
    }
}
