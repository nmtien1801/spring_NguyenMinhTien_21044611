package iuh.fit.week2.backend.data.DTO;

import lombok.*;

@Getter @Setter @ToString @AllArgsConstructor @NoArgsConstructor
public class DtoProduct {
    private Long id;
    private String description;
    private String manufacturer;
    private String name;
    private String status;
    private String unit;
    private double price;
    private String path;
}
