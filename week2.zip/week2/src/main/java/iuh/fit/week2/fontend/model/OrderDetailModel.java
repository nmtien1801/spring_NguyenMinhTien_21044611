package iuh.fit.week2.fontend.model;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import iuh.fit.week2.backend.data.entity.OrderDetail;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;

public class OrderDetailModel {
    private static final String URL = "http://localhost:8080/api/orderDetail/";

    public void insertOrderDetail(OrderDetail orderDetail) {
        try (Client client = ClientBuilder.newClient()) {
            WebTarget target = client.target(URL)
                    .path("insert");

            String json = new ObjectMapper().writeValueAsString(orderDetail);

            target
                    .request(MediaType.APPLICATION_JSON)
                    .post(jakarta.ws.rs.client.Entity.entity(json, MediaType.APPLICATION_JSON))
                    .getStatus();
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }
}
