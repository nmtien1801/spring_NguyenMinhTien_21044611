package iuh.fit.week2.fontend.controller;

import iuh.fit.week2.backend.data.entity.Customer;
import iuh.fit.week2.backend.data.entity.Employee;
import iuh.fit.week2.backend.data.entity.Order;
import iuh.fit.week2.fontend.model.CustomerModel;
import iuh.fit.week2.fontend.model.EmployeeModel;
import iuh.fit.week2.fontend.model.OrderModel;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

@WebServlet(name = "orderController", value = "/order")
public class OrderController extends HttpServlet {
    OrderModel orderModel = new OrderModel();
    EmployeeModel employeeModel = new EmployeeModel();
    CustomerModel customerModel = new CustomerModel();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");

        System.out.println("Action: " + action);

        if(action.equalsIgnoreCase("getall")){
            List<Employee> employees = employeeModel.getListEmployee();
            List<Customer> customers = customerModel.getListCustomer();
            List<Order> orders  = orderModel.getListOrder();

            // Loại bỏ ngày trùng lặp bằng cách sử dụng Set
            Set<String> uniqueDatesSet = new LinkedHashSet<>();
            for (Order order : orders) {
                uniqueDatesSet.add(order.getOrderDate().toLocalDateTime().toLocalDate().toString());
            }
            List<String> uniqueDates = new ArrayList<>(uniqueDatesSet);

            req.setAttribute("orders", orders);
            req.setAttribute("employees", employees);
            req.setAttribute("customers", customers);
            req.setAttribute("orderDates", uniqueDates);

            req.getRequestDispatcher("views/order.jsp").forward(req, resp);

        }
        else if(action.equalsIgnoreCase("getOrderByDate")){
            List<Employee> employees = employeeModel.getListEmployee();
            List<Customer> customers = customerModel.getListCustomer();
            List<Order> orders;

            String orderDateFilter = req.getParameter("value");
            if (orderDateFilter != null && !orderDateFilter.isEmpty()) {
                orders = orderModel.findOrdersByDay(LocalDate.parse(orderDateFilter));
            } else {
                orders = orderModel.getListOrder();     // lúc vào trang chưa có filter thì lấy tất cả
            }


            // Loại bỏ ngày trùng lặp bằng cách sử dụng Set
            Set<String> uniqueDatesSet = new LinkedHashSet<>();
            List<Order> dateFilteredOrders = orderModel.getListOrder();
            for (Order order : dateFilteredOrders) {
                uniqueDatesSet.add(order.getOrderDate().toLocalDateTime().toLocalDate().toString());
            }
            List<String> uniqueDates = new ArrayList<>(uniqueDatesSet);

            req.setAttribute("orders", orders);
            req.setAttribute("employees", employees);
            req.setAttribute("customers", customers);
            req.setAttribute("orderDates", uniqueDates);

            req.getRequestDispatcher("views/order.jsp").forward(req, resp);


        }
        else if(action.equalsIgnoreCase("getOrdersByDateRange")){
            List<Employee> employees = employeeModel.getListEmployee();
            List<Customer> customers = customerModel.getListCustomer();
            List<Order> orders;

            String startDateParam = req.getParameter("startDate");
            String endDateParam = req.getParameter("endDate");

            if (startDateParam != null && !startDateParam.isEmpty() && endDateParam != null && !endDateParam.isEmpty()) {
                LocalDateTime startDate = LocalDate.parse(startDateParam).atStartOfDay();
                LocalDateTime endDate = LocalDate.parse(endDateParam).atTime(23, 59, 59);
                orders = orderModel.findOrdersByTimeRange(startDate, endDate);
            } else {
                orders = orderModel.getListOrder();
            }

            // Loại bỏ ngày trùng lặp bằng cách sử dụng Set
            Set<String> uniqueDatesSet = new LinkedHashSet<>();
            List<Order> dateFilteredOrders = orderModel.getListOrder();
            for (Order order : dateFilteredOrders) {
                uniqueDatesSet.add(order.getOrderDate().toLocalDateTime().toLocalDate().toString());
            }
            List<String> uniqueDates = new ArrayList<>(uniqueDatesSet);

            req.setAttribute("orders", orders);
            req.setAttribute("employees", employees);
            req.setAttribute("customers", customers);
            req.setAttribute("orderDates", uniqueDates);

            req.getRequestDispatcher("views/order.jsp").forward(req, resp);
        }
        else if(action.equalsIgnoreCase("getOrdersByEmployeeAndTimeRange")){
            List<Employee> employees = employeeModel.getListEmployee();
            List<Customer> customers = customerModel.getListCustomer();
            List<Order> orders;

            Long empId = Long.parseLong(req.getParameter("empId"));
            String startDateParam = req.getParameter("startDate");
            String endDateParam = req.getParameter("endDate");

            if (startDateParam != null && !startDateParam.isEmpty() && endDateParam != null && !endDateParam.isEmpty()) {
                LocalDateTime startDate = LocalDate.parse(startDateParam).atStartOfDay();
                LocalDateTime endDate = LocalDate.parse(endDateParam).atTime(23, 59, 59);
                orders = orderModel.findOrdersByEmployeeAndTimeRange(empId, startDate, endDate);
            } else {
                orders = orderModel.getListOrder();
            }

            // Remove duplicate dates using Set
            Set<String> uniqueDatesSet = new LinkedHashSet<>();
            List<Order> dateFilteredOrders = orderModel.getListOrder();
            for (Order order : dateFilteredOrders) {
                uniqueDatesSet.add(order.getOrderDate().toLocalDateTime().toLocalDate().toString());
            }
            List<String> uniqueDates = new ArrayList<>(uniqueDatesSet);

            req.setAttribute("orders", orders);
            req.setAttribute("employees", employees);
            req.setAttribute("customers", customers);
            req.setAttribute("orderDates", uniqueDates);

            req.getRequestDispatcher("views/order.jsp").forward(req, resp);
        }
        else{
            System.out.println("Action not found");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");

        System.out.println("Action: " + action);

        if(action.equalsIgnoreCase("insert")){
            Employee employee = employeeModel.getEmployee(req.getParameter("emp_id"));
            Customer customer = customerModel.getCustomer(req.getParameter("cus_id"));
            LocalDateTime localDateTime = LocalDateTime.parse(req.getParameter("order_date"));
            Timestamp orderDate = Timestamp.valueOf(localDateTime);

            Order o = new Order();
            o.setEmp(employee);
            o.setCust(customer);
            o.setOrderDate(orderDate);

            orderModel.insertOrder(o);
            resp.sendRedirect("order?action=getall");
        }
        else if(action.equalsIgnoreCase("update")){
            String id = req.getParameter("id");
            Employee employee = employeeModel.getEmployee(req.getParameter("emp_id"));
            Customer customer = customerModel.getCustomer(req.getParameter("cus_id"));
            LocalDateTime localDateTime = LocalDateTime.parse(req.getParameter("order_date"));
            Timestamp orderDate = Timestamp.valueOf(localDateTime);


            Order o = orderModel.getOrder(id);
            o.setEmp(employee);
            o.setCust(customer);
            o.setOrderDate(orderDate);

            System.out.println("update FE: " + o);

            orderModel.putOrder(o);
            resp.sendRedirect("order?action=getall");
        }
        else if(action.equalsIgnoreCase("delete")){
            String id = req.getParameter("id");
            Order o = orderModel.getOrder(id);


            orderModel.deleteOrder(id);
            resp.sendRedirect("order?action=getall");
        }
        else{
            System.out.println("Action not found");
        }

    }
}
