package iuh.fit.week2.backend.data.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.ToString;

import java.time.Instant;
import java.util.Set;

@Entity
@Table(name = "customer")
@NamedQueries({
        @NamedQuery(name = "Customer.findAll", query = "select c from Customer c"),
        @NamedQuery(name = "Customer.findById", query = "select c from Customer c where c.id = :id")
})
@ToString
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @SequenceGenerator(name = "customer_seq", sequenceName = "customer_seq", allocationSize = 1)
    @Column(name = "cust_id", nullable = false)
    private Long id;

    @Size(max = 255)
    @NotNull
    @Column(name = "cust_name", nullable = false)
    private String custName;

    @Size(max = 255)
    @NotNull
    @Column(name = "email", nullable = false)
    private String email;

    @Size(max = 255)
    @Column(name = "phone")
    private String phone;

    @Column(name = "address")
    private String address;

    @OneToMany(mappedBy = "cust")
    @ToString.Exclude
    private Set<Order> orders;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public @Size(max = 255) @NotNull String getCustName() {
        return custName;
    }

    public void setCustName(@Size(max = 255) @NotNull String custName) {
        this.custName = custName;
    }

    public @Size(max = 255) @NotNull String getEmail() {
        return email;
    }

    public void setEmail(@Size(max = 255) @NotNull String email) {
        this.email = email;
    }

    public @Size(max = 255) String getPhone() {
        return phone;
    }

    public void setPhone(@Size(max = 255) String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
