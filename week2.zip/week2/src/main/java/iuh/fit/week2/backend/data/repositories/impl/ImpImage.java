package iuh.fit.week2.backend.data.repositories.impl;

import iuh.fit.week2.backend.data.ConnectDB;
import iuh.fit.week2.backend.data.entity.Customer;
import iuh.fit.week2.backend.data.entity.ProductImage;
import iuh.fit.week2.backend.data.repositories.dao.DaoImage;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import java.util.List;

public class ImpImage implements DaoImage {
    EntityManager em = new ConnectDB().getEntityManager();
    EntityTransaction transaction = em.getTransaction();

    @Override
    public List<ProductImage> findAll() {
        try {
            List<ProductImage> result = em.createNamedQuery("ProductImage.findAll").getResultList();
            System.out.println("get all BE: "+ result);
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("get all BE err: "+ e);
            return null;
        }
    }
}
