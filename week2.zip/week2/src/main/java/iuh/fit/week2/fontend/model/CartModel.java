package iuh.fit.week2.fontend.model;

import iuh.fit.week2.backend.data.DTO.DtoCart;
import iuh.fit.week2.backend.data.entity.Product;

import java.util.ArrayList;
import java.util.List;

public class CartModel {
    private List<DtoCart> cartItems = new ArrayList<>();

    public void addProductToCart(DtoCart product) {
        cartItems.add(product);
    }

    public List<DtoCart> getCartItems() {
        return cartItems;
    }

    // xoa toan bo san pham trong gio hang
    public void clearCart() {
        cartItems.clear();
    }
}