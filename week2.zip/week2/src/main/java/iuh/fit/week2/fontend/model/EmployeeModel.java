package iuh.fit.week2.fontend.model;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import iuh.fit.week2.backend.data.entity.Employee;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;

import java.util.ArrayList;
import java.util.List;

public class EmployeeModel {
    private static final String URL = "http://localhost:8080/api/employee/";

    public List<Employee> getListEmployee() {
        List<Employee> employees = new ArrayList<>();
        try (Client client = ClientBuilder.newClient()) {
            WebTarget target = client.target(URL);

            String json = target
                    .request(MediaType.APPLICATION_JSON)
                    .get()
                    .readEntity(String.class);

            ObjectMapper mapper = new ObjectMapper();
            employees = mapper.readValue(json, new TypeReference<List<Employee>>() {
            });

            System.out.println("employees FE: " + employees);

        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }

        return employees;
    }

    public Employee getEmployee(String id) throws JsonProcessingException {
        if (id == null) {
            throw new IllegalArgumentException("Employee ID cannot be null");
        }
        Employee e = new Employee();
        try (Client client = ClientBuilder.newClient()) {
            WebTarget target = client.target(URL)
                    .path(id);

            String json = target
                    .request(MediaType.APPLICATION_JSON)
                    .get()
                    .readEntity(String.class);

            ObjectMapper mapper = new ObjectMapper();
            e = mapper.readValue(json, Employee.class);

            System.out.println("get employee FE: " + e);

        } catch (JsonProcessingException e1) {
            throw new RuntimeException(e1);
        }

        return e;
    }

    public boolean insertEmployee(Employee employee) {
        try (Client client = ClientBuilder.newClient()) {
            WebTarget target = client.target(URL)
                    .path("insert");

            String json = new ObjectMapper().writeValueAsString(employee);

            return target
                    .request(MediaType.APPLICATION_JSON)
                    .post(jakarta.ws.rs.client.Entity.entity(json, MediaType.APPLICATION_JSON))
                    .getStatus() == 200;
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    public boolean putEmployee(Employee employee) {
        try (Client client = ClientBuilder.newClient()) {
            WebTarget target = client.target(URL)
                    .path("update");

            String json = new ObjectMapper().writeValueAsString(employee);

            return target
                    .request(MediaType.APPLICATION_JSON)
                    .put(Entity.entity(json, MediaType.APPLICATION_JSON))
                    .getStatus() == 200;
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }

    public boolean deleteEmployee(String id) {
        try (Client client = ClientBuilder.newClient()) {
            WebTarget target = client.target(URL)
                    .path("delete/").path(id);



//            String json = new ObjectMapper().writeValueAsString(employee);
//            System.out.println("delete model FE: " + json);
            return target
                    .request(MediaType.APPLICATION_JSON)
                    .delete()
                    .getStatus() == 200;
        }
    }
}
