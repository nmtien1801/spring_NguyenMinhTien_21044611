package iuh.fit.week2.backend.url.employee;

import iuh.fit.week2.backend.data.entity.Employee;
import iuh.fit.week2.backend.data.repositories.dao.DaoEmployee;
import iuh.fit.week2.backend.data.repositories.impl.ImplEmployee;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Response;

@Path("/employee")
public class UrlEmployee {
    DaoEmployee daoEmployee = new ImplEmployee();

    @GET
    @Produces("application/json")
    public Response getEmployee() {
        return Response.ok(daoEmployee.findAll()).build();
    }

    @GET
    @Produces("application/json")
    @Path("/{id}")
    public Response getEmployee(@PathParam("id") Long id) {
        return Response.ok(daoEmployee.findById(id)).build();
    }

    @POST
    @Consumes("application/json")
    @Path("/insert")
    public Response postEmployee(Employee employee) {
        if (daoEmployee.insert(employee)) {
            System.out.println("insert success BE: " + employee);
            return Response.ok().build();
        }
        return Response.status(500).build();
    }

    @PUT
    @Consumes("application/json")
    @Path("/update")
    public Response putEmployee(Employee employee) {
        if (daoEmployee.update(employee)) {
            System.out.println("update success BE: " + employee);
            return Response.ok().build();
        }
        return Response.status(500).build();
    }

    @DELETE
    @Consumes("application/json")
    @Path("/delete/{id}")
    public Response deleteEmployee(@PathParam("id") Long id) {
        Employee employee = daoEmployee.findById(id);
        System.out.println("delete success BE: " + employee);

        if (daoEmployee.delete(employee)) {

            return Response.ok().build();
        }
        return Response.status(500).build();
    }
}
