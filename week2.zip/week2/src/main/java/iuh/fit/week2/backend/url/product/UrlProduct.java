package iuh.fit.week2.backend.url.product;

import iuh.fit.week2.backend.data.entity.Product;
import iuh.fit.week2.backend.data.repositories.dao.DaoProduct;
import iuh.fit.week2.backend.data.repositories.impl.ImpDtoproduct;
import iuh.fit.week2.backend.data.repositories.impl.ImplProduct;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Response;

import java.util.List;

@Path("/product")
public class UrlProduct {
    DaoProduct daoProduct = new ImplProduct();
    ImpDtoproduct impDtoproduct = new ImpDtoproduct();

    @GET
    @Produces("application/json")
    public Response getProduct() {
        return Response.ok(daoProduct.findAll()).build();
    }

    @GET
    @Produces("application/json")
    @Path("/{id}")
    public Response getProduct(@PathParam("id") Long id) {
        return Response.ok(daoProduct.findById(id)).build();
    }

    @POST
    @Consumes("application/json")
    @Path("/insert")
    public Response postProduct(Product product) {
        if (daoProduct.insert(product)) {
            System.out.println("insert success BE: " + product);
            return Response.ok().build();
        }
        return Response.status(500).build();
    }

    @PUT
    @Consumes("application/json")
    @Path("/update")
    public Response putProduct(Product product) {
        if (daoProduct.update(product)) {
            System.out.println("update success BE: " + product);
            return Response.ok().build();
        }
        return Response.status(500).build();
    }

    @DELETE
    @Consumes("application/json")
    @Path("/delete/{id}")
    public Response deleteProduct(@PathParam("id") Long id) {
        Product product = daoProduct.findById(id);
        System.out.println("delete success BE: " + product);

        if (daoProduct.delete(product)) {

            return Response.ok().build();
        }
        return Response.status(500).build();
    }

    @GET
    @Produces("application/json")
    @Path("/home")
    public Response getProductDto() {
        return Response.ok(impDtoproduct.getAllDtoProduct()).build();
    }
}
