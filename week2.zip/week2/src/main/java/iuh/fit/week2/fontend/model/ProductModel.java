package iuh.fit.week2.fontend.model;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import iuh.fit.week2.backend.data.DTO.DtoProduct;
import iuh.fit.week2.backend.data.entity.Product;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.ClientBuilder;
import jakarta.ws.rs.client.Entity;
import jakarta.ws.rs.client.WebTarget;
import jakarta.ws.rs.core.MediaType;

import java.util.ArrayList;
import java.util.List;

public class ProductModel {
    private static final String URL = "http://localhost:8080/api/product/";

    public List<Product> getListProduct() {
        List<Product> products = new ArrayList<>();
        try (Client client = ClientBuilder.newClient()) {
            WebTarget target = client.target(URL);

            String json = target
                    .request(MediaType.APPLICATION_JSON)
                    .get()
                    .readEntity(String.class);

            ObjectMapper mapper = new ObjectMapper();
            products = mapper.readValue(json, new TypeReference<List<Product>>() {
            });

            System.out.println("products FE: " + products);

        } catch (JsonProcessingException p) {
            throw new RuntimeException(p);
        }

        return products;
    }

    public Product getProduct(String id) throws JsonProcessingException {
        if (id == null) {
            throw new IllegalArgumentException("Product ID cannot be null");
        }
        Product p = new Product();
        try (Client client = ClientBuilder.newClient()) {
            WebTarget target = client.target(URL)
                    .path(id);

            String json = target
                    .request(MediaType.APPLICATION_JSON)
                    .get()
                    .readEntity(String.class);

            ObjectMapper mapper = new ObjectMapper();
            p = mapper.readValue(json, Product.class);

            System.out.println("get product FE: " + p);

        } catch (JsonProcessingException e1) {
            throw new RuntimeException(e1);
        }

        return p;
    }

    public boolean insertProduct(Product product) {
        try (Client client = ClientBuilder.newClient()) {
            WebTarget target = client.target(URL)
                    .path("insert");

            String json = new ObjectMapper().writeValueAsString(product);

            return target
                    .request(MediaType.APPLICATION_JSON)
                    .post(jakarta.ws.rs.client.Entity.entity(json, MediaType.APPLICATION_JSON))
                    .getStatus() == 200;
        } catch (JsonProcessingException p) {
            throw new RuntimeException(p);
        }
    }

    public boolean putProduct(Product product) {
        try (Client client = ClientBuilder.newClient()) {
            WebTarget target = client.target(URL)
                    .path("update");

            String json = new ObjectMapper().writeValueAsString(product);

            return target
                    .request(MediaType.APPLICATION_JSON)
                    .put(Entity.entity(json, MediaType.APPLICATION_JSON))
                    .getStatus() == 200;
        } catch (JsonProcessingException p) {
            throw new RuntimeException(p);
        }
    }

    public boolean deleteProduct(String id) {
        try (Client client = ClientBuilder.newClient()) {
            WebTarget target = client.target(URL)
                    .path("delete/").path(id);


//            String json = new ObjectMapper().writeValueAsString(product);
//            System.out.println("delete model FE: " + json);
            return target
                    .request(MediaType.APPLICATION_JSON)
                    .delete()
                    .getStatus() == 200;
        }
    }

    public List<DtoProduct> getListProductDto() {
        List<DtoProduct> dtoProducts = new ArrayList<>();
        try (Client client = ClientBuilder.newClient()) {
            WebTarget target = client.target(URL).path("home");

            String json = target
                    .request(MediaType.APPLICATION_JSON)
                    .get()
                    .readEntity(String.class);

            ObjectMapper mapper = new ObjectMapper();
            dtoProducts = mapper.readValue(json, new TypeReference<List<DtoProduct>>() {
            });

            System.out.println("dtoProducts FE: " + dtoProducts);

        } catch (JsonProcessingException p) {
            throw new RuntimeException(p);
        }

        return dtoProducts;
    }
}
