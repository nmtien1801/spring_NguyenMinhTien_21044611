package iuh.fit.week2.backend.data.repositories.dao;

import iuh.fit.week2.backend.data.entity.Product;

import java.util.List;

public interface DaoProduct {
    public boolean insert(Product p);

    public boolean update(Product p);

    public boolean delete(Product p);

    public Product findById(Long aLong);

    public List<Product> findAll();
}
