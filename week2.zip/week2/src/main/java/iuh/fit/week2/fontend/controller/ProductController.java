package iuh.fit.week2.fontend.controller;

import iuh.fit.week2.backend.data.DTO.DtoProduct;
import iuh.fit.week2.backend.data.entity.Product;
import iuh.fit.week2.backend.data.entity.ProductImage;
import iuh.fit.week2.backend.data.entity.enums.StatusEmployee;
import iuh.fit.week2.backend.data.entity.enums.StatusProduct;
import iuh.fit.week2.fontend.model.ProductModel;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "productController", value = "/product")
public class ProductController extends HttpServlet {
    ProductModel model = new ProductModel();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");

        System.out.println("Action: " + action);

        if(action.equalsIgnoreCase("getall")){
            List<Product> products = model.getListProduct();
            req.setAttribute("products", products);
            req.getRequestDispatcher("views/product.jsp").forward(req, resp);

        }
        else if(action.equalsIgnoreCase("home")){
            List<DtoProduct> dtoProducts = model.getListProductDto();

            req.setAttribute("products", dtoProducts);
            req.getRequestDispatcher("views/home.jsp").forward(req, resp);
        }
        else{
            System.out.println("Action not found");
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String action = req.getParameter("action");

        System.out.println("Action: " + action);

        if(action.equalsIgnoreCase("insert")){
            String name = req.getParameter("name");
            String desc = req.getParameter("desc");
            String unit = req.getParameter("unit");
            StatusProduct statusProduct  = StatusProduct.valueOf(req.getParameter("status"));
            String manufacturer = req.getParameter("manufacturer");

            Product p = new Product();
            p.setDescription(desc);
            p.setManufacturer(manufacturer);
            p.setName(name);
            p.setStatus(statusProduct);
            p.setUnit(unit);


            model.insertProduct(p);
            resp.sendRedirect("product?action=getall");
        }
        else if(action.equalsIgnoreCase("update")){
            String id = req.getParameter("id");
            String name = req.getParameter("name");
            String desc = req.getParameter("desc");
            String unit = req.getParameter("unit");
            StatusProduct statusProduct  = StatusProduct.valueOf(req.getParameter("status"));
            String manufacturer = req.getParameter("manufacturer");


            Product p = model.getProduct(id);
            p.setDescription(desc);
            p.setManufacturer(manufacturer);
            p.setName(name);
            p.setStatus(statusProduct);
            p.setUnit(unit);

            System.out.println("update FE: " + p);

            model.putProduct(p);
            resp.sendRedirect("product?action=getall");
        }
        else if(action.equalsIgnoreCase("delete")){
            String id = req.getParameter("id");
            Product p = model.getProduct(id);


            model.deleteProduct(id);
            resp.sendRedirect("product?action=getall");
        }
        else{
            System.out.println("Action not found");
        }

    }
}
