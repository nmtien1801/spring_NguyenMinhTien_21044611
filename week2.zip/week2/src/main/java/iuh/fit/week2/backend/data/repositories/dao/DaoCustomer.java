package iuh.fit.week2.backend.data.repositories.dao;

import iuh.fit.week2.backend.data.entity.Customer;

import java.util.List;

public interface DaoCustomer {
    public boolean insert(Customer p);

    public boolean update(Customer p);

    public boolean delete(Customer p);

    public Customer findById(Long aLong);

    public List<Customer> findAll();
}
