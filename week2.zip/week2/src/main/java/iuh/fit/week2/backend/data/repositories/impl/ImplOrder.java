package iuh.fit.week2.backend.data.repositories.impl;

import iuh.fit.week2.backend.data.ConnectDB;
import iuh.fit.week2.backend.data.entity.Order;
import iuh.fit.week2.backend.data.entity.Order;
import iuh.fit.week2.backend.data.entity.Order;
import iuh.fit.week2.backend.data.entity.Order;
import iuh.fit.week2.backend.data.repositories.dao.DaoOrder;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.NoResultException;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

public class ImplOrder implements DaoOrder {
    EntityManager em = new ConnectDB().getEntityManager();
    EntityTransaction transaction = em.getTransaction();
    
    @Override
    public boolean insert(Order p) {
        try {
            transaction.begin();
            em.persist(p);
            em.flush(); // Đảm bảo dữ liệu được ghi vào DB
            em.refresh(p);
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
            return false;
        }
        return true;
    }

    @Override
    public boolean update(Order o) {
        try {
            transaction.begin();
            em.merge(o);
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
            return false;
        }
        return true;
    }

    @Override
    public boolean delete(Order p) {
        try {
            System.out.println("delete impl BE: " + p);
            transaction.begin();
            em.remove(p);
            transaction.commit();
        } catch (Exception e) {
            transaction.rollback();
            e.printStackTrace();
            return false;
        }
        return true;
    }

    @Override
    public Order findById(Long aLong) {
        try {
            Order result = em.find(Order.class, aLong);
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Order> findAll() {
        try {
            List<Order> result = em.createNamedQuery("Order.findAll", Order.class).getResultList();
            System.out.println("get all BE: "+ result);
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Order> findOrdersByTimeRange(LocalDateTime startDate, LocalDateTime endDate) {
        try {
            List<Order> result = em.createQuery("SELECT o FROM Order o WHERE o.orderDate BETWEEN :startDate AND :endDate", Order.class)
                    .setParameter("startDate", startDate)
                    .setParameter("endDate", endDate)
                    .getResultList();
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Order> findOrdersByDay(LocalDate date) {
        try {
            List<Order> result = em.createQuery("SELECT o FROM Order o WHERE DATE(o.orderDate) = :date", Order.class)
                    .setParameter("date", date)
                    .getResultList();
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Order> findOrdersByEmployeeAndTimeRange(Long empId, LocalDateTime startDate, LocalDateTime endDate) {
        try {
            List<Order> result = em.createQuery("SELECT o FROM Order o WHERE o.emp.id = :empId AND o.orderDate BETWEEN :startDate AND :endDate", Order.class)
                    .setParameter("empId", empId)
                    .setParameter("startDate", startDate)
                    .setParameter("endDate", endDate)
                    .getResultList();
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public Order findLatestOrder() {
        try {
            String jpql = "SELECT o FROM Order o ORDER BY o.orderDate DESC";
            return em.createQuery(jpql, Order.class)
                    .setMaxResults(1)
                    .getSingleResult();
        } catch (NoResultException e) {
            System.out.println("No orders found.");
            return null;
        }
    }

}
