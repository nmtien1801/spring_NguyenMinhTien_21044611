package iuh.fit.week2.backend.data.repositories.impl;

import iuh.fit.week2.backend.data.ConnectDB;
import iuh.fit.week2.backend.data.entity.ProductPrice;
import iuh.fit.week2.backend.data.repositories.dao.DaoPrice;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import java.util.List;

public class ImplPrice implements DaoPrice {
    EntityManager em = new ConnectDB().getEntityManager();
    EntityTransaction transaction = em.getTransaction();

    @Override
    public List<ProductPrice> findAll() {
        try {
            List<ProductPrice> result = em.createNamedQuery("ProductPrice.findAll").getResultList();
            System.out.println("get all BE: "+ result);
            return result;
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("get all BE err: "+ e);
            return null;
        }
    }
}
