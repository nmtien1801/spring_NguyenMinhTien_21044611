package iuh.fit.week2.backend.data.repositories.dao;

import iuh.fit.week2.backend.data.entity.ProductPrice;

import java.util.List;

public interface DaoPrice {
    public List<ProductPrice> findAll();
}
