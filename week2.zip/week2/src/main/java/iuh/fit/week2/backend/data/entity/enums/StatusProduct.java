package iuh.fit.week2.backend.data.entity.enums;

public enum StatusProduct {
    ACTIVE, IN_ACTIVE, TERMINATED
}
